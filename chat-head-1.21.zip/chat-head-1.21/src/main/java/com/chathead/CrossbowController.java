package com.chathead;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class CrossbowController {
    private enum Step { IDLE, PLACE_RAIL, PLACE_CART, CHARGE, AIM, SHOOT, FLINT_AIM, FLINT_USE }

    private Step step = Step.IDLE;
    private int wait;
    private int cooldown;
    private int chargeAttempts;
    private BlockPos railBase;
    private BlockPos railPos;
    private int railSlot;
    private int cartSlot;
    private int crossbowSlot;
    private int flintSlot;
    private boolean useFlame;
    private BlockPos fireBlock;
    private int savedSlot;
    private float savedYaw;
    private float savedPitch;

    public void tick(MinecraftClient client, boolean triggered) {
        ChatHeadConfig cfg = ChatHeadClient.CONFIG;
        ClientPlayerEntity player = client.player;
        if (cooldown > 0) cooldown--;
        if (player == null || client.world == null || client.interactionManager == null) {
            step = Step.IDLE;
            return;
        }
        if (step == Step.IDLE) {
            if (triggered && cfg.enabled && cooldown == 0) start(client, player, cfg);
            return;
        }
        if (client.currentScreen != null) {
            fail(client, player, "đóng GUI đã");
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }
        switch (step) {
            case PLACE_RAIL -> placeRail(client, player, cfg);
            case PLACE_CART -> placeCart(client, player, cfg);
            case CHARGE -> charge(client, player, cfg);
            case AIM -> aim(client, player, cfg);
            case SHOOT -> shoot(client, player, cfg);
            case FLINT_AIM -> flintAim(client, player, cfg);
            case FLINT_USE -> flintUse(client, player, cfg);
            default -> step = Step.IDLE;
        }
    }

    private void start(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        if (!(client.crosshairTarget instanceof BlockHitResult hit)
                || hit.getType() != HitResult.Type.BLOCK
                || hit.getSide() != Direction.UP) {
            say(player, "nhìn vào mặt trên của một block");
            return;
        }
        railBase = hit.getBlockPos();
        railPos = railBase.up();
        if (!client.world.getBlockState(railPos).isAir()) {
            say(player, "ô trên block đang bị chiếm");
            return;
        }
        if (!client.world.getBlockState(railBase).isSolidBlock(client.world, railBase)) {
            say(player, "block dưới không đặc");
            return;
        }
        PlayerInventory inv = player.getInventory();
        railSlot = findInHotbar(inv, Items.RAIL);
        cartSlot = findInHotbar(inv, Items.TNT_MINECART);
        crossbowSlot = findFlameCrossbow(inv);
        flintSlot = findInHotbar(inv, Items.FLINT_AND_STEEL);
        boolean flameReady = crossbowSlot >= 0 && hasArrow(inv);
        boolean flintReady = flintSlot >= 0;
        if (railSlot < 0 || cartSlot < 0) {
            say(player, "thiếu rail hoặc tnt minecart trong hotbar");
            return;
        }
        if (!flameReady && !flintReady) {
            say(player, "thiếu nỏ flame có mũi tên, hoặc bật lửa, trong hotbar");
            return;
        }
        String mode = cfg.ignition == null ? "AUTO" : cfg.ignition.toUpperCase(Locale.ROOT);
        useFlame = switch (mode) {
            case "FLAME" -> true;
            case "FLINT" -> false;
            default -> flameReady;
        };
        if (useFlame && !flameReady) {
            say(player, "chế độ FLAME nhưng thiếu nỏ flame có mũi tên");
            return;
        }
        if (!useFlame && !flintReady) {
            say(player, "chế độ FLINT nhưng thiếu bật lửa trong hotbar");
            return;
        }
        savedSlot = inv.selectedSlot;
        savedYaw = player.getYaw();
        savedPitch = player.getPitch();
        chargeAttempts = 0;
        wait = 0;
        step = Step.PLACE_RAIL;
    }

    private void placeRail(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        selectSlot(client, player, railSlot);
        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(railBase).add(0, 0.5, 0), Direction.UP, railBase, false);
        ActionResult result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (!result.isAccepted()) {
            fail(client, player, "đặt rail thất bại");
            return;
        }
        wait = cfg.actionDelayTicks;
        step = Step.PLACE_CART;
    }

    private void placeCart(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        if (!client.world.getBlockState(railPos).isIn(BlockTags.RAILS)) {
            fail(client, player, "rail chưa lên");
            return;
        }
        selectSlot(client, player, cartSlot);
        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(railPos).add(0, 0.5, 0), Direction.UP, railPos, false);
        ActionResult result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (!result.isAccepted()) {
            fail(client, player, "đặt tnt minecart thất bại");
            return;
        }
        wait = cfg.actionDelayTicks;
        step = useFlame ? Step.CHARGE : Step.FLINT_AIM;
    }

    private void flintAim(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        BlockPos fire = findFirePosition(client, player, railBase);
        if (fire == null) {
            fail(client, player, "không có chỗ đặt lửa cạnh rail");
            return;
        }
        fireBlock = fire;
        selectSlot(client, player, flintSlot);
        aimAt(player, Vec3d.ofCenter(fireBlock).add(0, 0.5, 0));
        wait = cfg.aimTicks;
        step = Step.FLINT_USE;
    }

    private void flintUse(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(fireBlock).add(0, 0.5, 0), Direction.UP, fireBlock, false);
        ActionResult result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        if (!result.isAccepted()) {
            fail(client, player, "bật lửa thất bại");
            return;
        }
        restore(client, player);
        cooldown = cfg.cooldownTicks;
        step = Step.IDLE;
    }

    private void charge(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        selectSlot(client, player, crossbowSlot);
        if (CrossbowItem.isCharged(player.getMainHandStack())) {
            if (player.isUsingItem()) client.interactionManager.stopUsingItem(player);
            step = Step.AIM;
            wait = cfg.actionDelayTicks;
            return;
        }
        if (player.isUsingItem()) {
            client.interactionManager.stopUsingItem(player);
            wait = cfg.actionDelayTicks;
            return;
        }
        if (++chargeAttempts > 3) {
            fail(client, player, "nỏ không nạp được");
            return;
        }
        ActionResult result = client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        if (!result.isAccepted()) {
            fail(client, player, "không bắt đầu nạp nỏ được");
            return;
        }
        wait = cfg.chargeTicks;
    }

    private void aim(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        TntMinecartEntity cart = findCart(client);
        if (cart == null) {
            fail(client, player, "không thấy tnt minecart");
            return;
        }
        aimAt(player, cart.getBoundingBox().getCenter());
        wait = cfg.aimTicks;
        step = Step.SHOOT;
    }

    private void shoot(MinecraftClient client, ClientPlayerEntity player, ChatHeadConfig cfg) {
        selectSlot(client, player, crossbowSlot);
        if (!CrossbowItem.isCharged(player.getMainHandStack())) {
            fail(client, player, "nỏ mất charge trước khi bắn");
            return;
        }
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        restore(client, player);
        cooldown = cfg.cooldownTicks;
        step = Step.IDLE;
    }

    private void fail(MinecraftClient client, ClientPlayerEntity player, String reason) {
        if (player.isUsingItem()) client.interactionManager.stopUsingItem(player);
        restore(client, player);
        say(player, reason);
        step = Step.IDLE;
    }

    private void restore(MinecraftClient client, ClientPlayerEntity player) {
        selectSlot(client, player, savedSlot);
        player.setYaw(savedYaw);
        player.setPitch(savedPitch);
    }

    private TntMinecartEntity findCart(MinecraftClient client) {
        Vec3d center = Vec3d.ofCenter(railPos);
        List<TntMinecartEntity> carts = client.world.getEntitiesByClass(
                TntMinecartEntity.class, new Box(railPos).expand(1.0), cart -> true);
        return carts.stream()
                .min(Comparator.comparingDouble((TntMinecartEntity cart) -> cart.squaredDistanceTo(center)))
                .orElse(null);
    }

    private static BlockPos findFirePosition(MinecraftClient client, ClientPlayerEntity player, BlockPos base) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);
        BlockPos best = null;
        double bestScore = -2.0;
        for (Direction dir : new Direction[] {Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            BlockPos candidate = base.offset(dir);
            if (!client.world.getBlockState(candidate).isReplaceable()) continue;
            if (!client.world.isAir(candidate.up())) continue;
            double score = Vec3d.ofCenter(candidate).subtract(eye).normalize().dotProduct(look);
            if (score > bestScore) {
                bestScore = score;
                best = candidate;
            }
        }
        return best;
    }

    private static void aimAt(ClientPlayerEntity player, Vec3d target) {
        Vec3d d = target.subtract(player.getEyePos());
        double horizontal = Math.sqrt(d.x * d.x + d.z * d.z);
        player.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        player.setPitch((float) -Math.toDegrees(Math.atan2(d.y, horizontal)));
    }

    private static void selectSlot(MinecraftClient client, ClientPlayerEntity player, int slot) {
        player.getInventory().selectedSlot = slot;
        client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private static int findInHotbar(PlayerInventory inv, Item item) {
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private static int findFlameCrossbow(PlayerInventory inv) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(Items.CROSSBOW) && hasFlame(stack)) return i;
        }
        return -1;
    }

    private static boolean hasFlame(ItemStack stack) {
        ItemEnchantmentsComponent enchantments = EnchantmentHelper.getEnchantments(stack);
        for (RegistryEntry<Enchantment> entry : enchantments.getEnchantments()) {
            if (entry.matchesKey(Enchantments.FLAME) && enchantments.getLevel(entry) > 0) return true;
        }
        return false;
    }

    private static boolean hasArrow(PlayerInventory inv) {
        for (int i = 0; i < inv.size(); i++) {
            if (inv.getStack(i).isIn(ItemTags.ARROWS)) return true;
        }
        return false;
    }

    private static void say(ClientPlayerEntity player, String message) {
        player.sendMessage(Text.literal("[chat_head] " + message), true);
    }
}
