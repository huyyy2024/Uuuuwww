package com.chathead;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class ChatHeadConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    public int actionDelayTicks = 2;
    public int chargeTicks = 30;
    public int aimTicks = 2;
    public int cooldownTicks = 10;
    // AUTO: flame crossbow if ready, otherwise flint and steel. FLAME or FLINT forces one path.
    public String ignition = "AUTO";

    public static ChatHeadConfig load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("chat_head").resolve("chat_head.json");
        try {
            Files.createDirectories(path.getParent());
            if (Files.exists(path)) {
                try (Reader reader = Files.newBufferedReader(path)) {
                    ChatHeadConfig loaded = GSON.fromJson(reader, ChatHeadConfig.class);
                    if (loaded != null) return loaded;
                }
            }
            ChatHeadConfig defaults = new ChatHeadConfig();
            try (Writer writer = Files.newBufferedWriter(path)) {
                GSON.toJson(defaults, writer);
            }
            return defaults;
        } catch (IOException e) {
            return new ChatHeadConfig();
        }
    }
}
